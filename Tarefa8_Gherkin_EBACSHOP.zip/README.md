# Tarefa 8 - Critérios de Aceitação em Gherkin (EBAC-SHOP)

## 🧾 Descrição
Este repositório contém os arquivos `.feature` desenvolvidos como parte da **Tarefa 8** do curso de **Engenharia de Qualidade de Software** (EBAC).

O objetivo é converter os **critérios de aceitação** das histórias de usuário do projeto EBAC-SHOP para o formato **Gherkin**, aplicando boas práticas como:
- Reaproveitamento de contexto (`Background`);
- Uso de **cenários e esquemas de cenário** (`Scenario` e `Scenario Outline`);
- Escrita clara e padronizada dos critérios de aceitação.

---

## 📁 Estrutura dos Arquivos
```
Módulo8-Gherkin/
├── login.feature
├── configurar_produto.feature
└── cadastro_checkout.feature
```

---

## 💻 Como Executar no Visual Studio Code
1. Instale a extensão **Cucumber (Gherkin) Full Support** no VS Code.
2. Abra a pasta do projeto.
3. Abra qualquer arquivo `.feature` para visualizar a estrutura Gherkin com destaque de sintaxe.

---

## 🚀 Entrega
- Subir os arquivos `.feature` no seu repositório GitHub.
- Enviar o link do repositório na plataforma da EBAC.
